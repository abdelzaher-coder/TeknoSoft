import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'To-Do List App',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: ToDoListScreen(),
    );
  }
}

class ToDoListScreen extends StatefulWidget {
  @override
  _ToDoListScreenState createState() => _ToDoListScreenState();
}

class _ToDoListScreenState extends State<ToDoListScreen> {
  List<Task> tasks = [
    Task(
        id: 1,
        title: 'Task 1',
        description: 'Description 1',
        category: 'Personal',
        priority: 'High',
        isCompleted: false),
    Task(
        id: 2,
        title: 'Task 2',
        description: 'Description 2',
        category: 'Work',
        priority: 'Medium',
        isCompleted: false),
    Task(
        id: 3,
        title: 'Task 3',
        description: 'Description 3',
        category: 'Shopping',
        priority: 'Low',
        isCompleted: false),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('To-Do List'),
      ),
      body: ListView.builder(
        itemCount: tasks.length,
        itemBuilder: (context, index) {
          Task task = tasks[index];
          return Column(
            children: [
              _buildDateWidget(), // Date of the day
              Dismissible(
                key: Key(task.id.toString()),
                onDismissed: (direction) {
                  setState(() {
                    tasks.removeAt(index);
                  });
                },
                background: Container(color: Colors.red),
                child: Card(
                  elevation: 2.0,
                  margin: EdgeInsets.symmetric(horizontal: 8.0, vertical: 4.0),
                  child: ListTile(
                    title: Text(task.title,
                        style: TextStyle(fontWeight: FontWeight.bold)),
                    subtitle: Text(task.description),
                    trailing: Checkbox(
                      value: task.isCompleted,
                      onChanged: (value) {
                        _confirmDeleteTask(context, index, task);
                      },
                    ),
                  ),
                ),
              ),
            ],
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          _navigateToTaskScreen(context);
        },
        child: Icon(Icons.add),
      ),
    );
  }

  Widget _buildDateWidget() {
    String formattedDate =
        DateTime.now().toString().substring(0, 10); // Format: yyyy-mm-dd
    return Padding(
      padding: EdgeInsets.all(8.0),
      child: Text(
        formattedDate,
        style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
      ),
    );
  }

  void _navigateToTaskScreen(BuildContext context) async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => TaskScreen()),
    );

    if (result != null) {
      setState(() {
        tasks.add(result);
      });
    }
  }

  void _confirmDeleteTask(BuildContext context, int index, Task task) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Confirm'),
          content: Text(
              'Are you sure you want to mark this task as completed? It will be deleted from the list.'),
          actions: <Widget>[
            TextButton(
              child: Text('CANCEL'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
            TextButton(
              child: Text('OK'),
              onPressed: () {
                setState(() {
                  tasks.removeAt(index);
                });
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }
}

class TaskScreen extends StatefulWidget {
  @override
  _TaskScreenState createState() => _TaskScreenState();
}

class _TaskScreenState extends State<TaskScreen> {
  late TextEditingController _titleController;
  late TextEditingController _descriptionController;
  late String _category;
  late String _priority;

  @override
  void initState() {
    super.initState();
    _titleController = TextEditingController();
    _descriptionController = TextEditingController();
    _category = 'Personal';
    _priority = 'Low';
  }

  @override
  void dispose() {
    _titleController.dispose();
    _descriptionController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Add Task'),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextField(
              controller: _titleController,
              decoration: InputDecoration(labelText: 'Title'),
            ),
            SizedBox(height: 12.0),
            TextField(
              controller: _descriptionController,
              decoration: InputDecoration(labelText: 'Description'),
            ),
            SizedBox(height: 12.0),
            DropdownButtonFormField<String>(
              value: _category,
              items: ['Personal', 'Work', 'Shopping'].map((String category) {
                return DropdownMenuItem<String>(
                  value: category,
                  child: Text(category),
                );
              }).toList(),
              onChanged: (value) {
                setState(() {
                  _category = value!;
                });
              },
              decoration: InputDecoration(labelText: 'Category'),
            ),
            SizedBox(height: 12.0),
            DropdownButtonFormField<String>(
              value: _priority,
              items: ['High', 'Medium', 'Low'].map((String priority) {
                return DropdownMenuItem<String>(
                  value: priority,
                  child: Text(priority),
                );
              }).toList(),
              onChanged: (value) {
                setState(() {
                  _priority = value!;
                });
              },
              decoration: InputDecoration(labelText: 'Priority'),
            ),
            SizedBox(height: 12.0),
            ElevatedButton(
              onPressed: () {
                Task newTask = Task(
                  id: DateTime.now().millisecondsSinceEpoch,
                  title: _titleController.text,
                  description: _descriptionController.text,
                  category: _category,
                  priority: _priority,
                  isCompleted: false,
                );

                Navigator.pop(context, newTask);
              },
              child: Text('Add Task'),
            ),
          ],
        ),
      ),
    );
  }
}

class Task {
  int id;
  String title;
  String description;
  String category;
  String priority;
  bool isCompleted;

  Task({
    required this.id,
    required this.title,
    required this.description,
    required this.category,
    required this.priority,
    required this.isCompleted,
  });
}
